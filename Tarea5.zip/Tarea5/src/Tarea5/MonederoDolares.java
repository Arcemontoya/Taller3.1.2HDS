package Tarea5;

public class MonederoDolares {

	private int uno;
	private int cinco;
	private int diez;
	private int veinticinco;
	
	public void retirar(int uno, int cinco, int diez, int veinticinco)
	{
		if (uno > this.uno)
		{
			this.uno = 0;
		}else
		{
			this.uno -= uno;
		}
		
		
		if (cinco > this.cinco)
		{
			this.cinco = 0;
		}else
		{
			this.cinco -= cinco;
		}
		
		if (diez > this.diez)
		{
			this.diez = 0;
		}else
		{
			this.diez -= diez;
		}
		
		if (veinticinco > this.veinticinco)
		{
			this.veinticinco = 0;
		}else
		{
			this.veinticinco -= veinticinco;
		}
		
	}
	
	public void depositar(int uno, int cinco, int diez, int veinticinco)
	{
		this.uno += uno;
		
		this.cinco += cinco;
		
		this.diez += diez;
		
		this.veinticinco += veinticinco;
		
	}	
		
	public int getUno() {
		return uno;
	}

	public void setUno(int uno) {
		this.uno = uno;
	}

	public int getCinco() {
		return cinco;
	}
	public void setCinco(int cinco) {
		this.cinco = cinco;
	}
	public int getDiez() {
		return diez;
	}
	public void setDiez(int diez) {
		this.diez = diez;
	}
	public int getVeinticinco() {
		return veinticinco;
	}
	public void setVeinticinco(int veinticinco) {
		this.veinticinco = veinticinco;
	}

	public int total()
	{
		return (1*uno+cinco*5+diez*10+25*veinticinco);
	}

	@Override
	public String toString() {
		return "MonederoDolares [uno=" + uno + ", cinco=" + cinco + ", diez=" + diez + ", veinticinco=" + veinticinco
				+ "]";
	}

	
	
}
