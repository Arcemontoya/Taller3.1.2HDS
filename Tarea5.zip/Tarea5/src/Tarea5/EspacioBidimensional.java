package Tarea5;

import java.util.Scanner;

public class EspacioBidimensional {
	
	private int x, y;
	

	public int getX() {
		return x;
	}

	public void setX(int x) {
		this.x = x;
	}

	public int getY() {
		return y;
	}

	public void setY(int y) {
		this.y = y;
	}
	
	public void mover()
	{
		try(Scanner sc = new Scanner(System.in)){
			System.out.println("Ingrese coordenada X: ");
			setX(sc.nextInt());
			System.out.println("Ingrese coordenada Y: ");
			setY(sc.nextInt());
		}
	}
	
	@Override
	public String toString()
	{
		return "Las coordenadas finales son ("+getX()+", "+getY()+").";
	}
	
}
