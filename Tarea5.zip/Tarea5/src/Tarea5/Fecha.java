package Tarea5;

public class Fecha {
	
	private int dia;
	private String mes = "default";
	private int anio;
	
	
	public void mostrarFecha()
	{
		System.out.println("\t-> "+dia+" "+" "+mes+" "+anio);
	}
	
	public int getDia() {
		return dia;
	}
	
	public void setDia(int dia) {
		this.dia = dia;
	}
	
	public String getMes() {
		return mes;
	}
	
	public void setMes(String mes) {
		
		this.mes = mes.toLowerCase();
		
	}
	
	public int getAnio() {
		return anio;
	}
	
	public void setAnio(int anio) {
		this.anio = anio;
	}
	
	@Override
	public String toString() {
		return "Fecha [dia=" + dia + ", mes=" + mes + ", anio=" + anio + "]";
	}
	
	
	
	
}
