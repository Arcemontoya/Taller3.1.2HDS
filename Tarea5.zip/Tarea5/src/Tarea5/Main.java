package Tarea5;

import java.util.Scanner;

public class Main {
	
	
	public static void main(String []args)
	{
		try(Scanner sc = new Scanner(System.in))
		{
			MonederoDolares md = new MonederoDolares();
			Fecha fecha = new Fecha();
			EspacioBidimensional eb = new EspacioBidimensional();
			Persona persona = new Persona();
			
			while (true)
			{
				MenuMain();
				int opcion1 = sc.nextInt();
				switch(opcion1)
				{
				case 1:
					Menu1();
					int opcion2 = sc.nextInt();
					switch (opcion2)
					{
					case 1:
						System.out.println("\t-> Ingrese coordenada en X: ");
						eb.setX(sc.nextInt());
						System.out.println("\t-> Ingrese coordenada en Y: ");
						eb.setY(sc.nextInt());
						System.out.println(eb.toString());
						break;
					case 2:
						eb.mover();
						break;
					case 3:
						System.out.println(eb.toString());
						break;
					}
					break;
				case 2:
					Menu2();
					int opcion3 = sc.nextInt();
					switch(opcion3)
					{
					case 1:
						System.out.println("\t -> Ingresa monedas de 1 centavo: ");
						int uno1 = sc.nextInt();
						System.out.println("\t -> Ingresa monedas de 5 centavos: ");
						int cinco1 = sc.nextInt();
						System.out.println("\t -> Ingresa monedas de 10 centavos: ");
						int diez1 = sc.nextInt();
						System.out.println("\t -> Ingresa monedas de 25 centavos: ");
						int veinticinco1 = sc.nextInt();
						md.depositar(uno1, cinco1, diez1, veinticinco1);
						break;
					case 2:
						System.out.println("\t -> Ingrese retiro de monedas de 1 centavo: ");
						int uno = sc.nextInt();
						System.out.println("\t -> Ingrese retiro de monedas de 5 centavos: ");
						int cinco = sc.nextInt();
						System.out.println("\t -> Ingrese retiro de monedas de 10 centavos: ");
						int diez = sc.nextInt();
						System.out.println("\t -> Ingrese retiro de monedas de 25 centavos: ");
						int veinticinco = sc.nextInt();
						md.retirar(uno, cinco, diez, veinticinco);
					case 3:
						System.out.println("\t -> El total del dinero es: "+ md.total()+"$");
						break;
					case 4:
						System.out.println(md.toString());
					}
					break;
				case 3:
					Menu3();
					int opcion4 = sc.nextInt();
					switch(opcion4)
					{
					case 1:
						System.out.println("\t -> Ingrese dia: ");
						fecha.setDia(sc.nextInt());
						
						do {
							System.out.println("\t -> Ingrese mes: ");
							sc.nextLine();
							fecha.setMes(sc.nextLine());
						}while(fecha.getMes().equals("enero") != true &&
								fecha.getMes().equals("enero") != true &&
								fecha.getMes().equals("febrero") != true &&
								fecha.getMes().equals("marzo") != true &&
								fecha.getMes().equals("abril") != true &&
								fecha.getMes().equals("mayo") != true &&
								fecha.getMes().equals("junio") != true &&
								fecha.getMes().equals("julio") != true &&
								fecha.getMes().equals("agosto") != true &&
								fecha.getMes().equals("septiembre") != true &&
								fecha.getMes().equals("octubre") != true &&
								fecha.getMes().equals("noviembre") != true &&
								fecha.getMes().equals("diciembre") != true);
						System.out.println("\t -> Ingrese anio: ");
						fecha.setAnio(sc.nextInt());
						break;
					case 2:
						fecha.mostrarFecha();
						break;
					case 3:
						System.out.println(fecha.toString());
						break;
					}
					break;
				case 4:
					Menu4();
					int opcion5 = sc.nextInt();
					switch(opcion5)
					{
					case 1:
						System.out.println("\t-> Ingrese nombre de la persona: ");
						sc.nextLine();
						persona.setNombre(sc.nextLine());
						System.out.println("\t-> Ingrese apellido paterno de la persona: ");
						persona.setApellidoPaterno(sc.nextLine());
						System.out.println("\t-> Ingrese apellido materno de la persona: ");
						persona.setApellidoMaterno(sc.nextLine());
						break;
					case 2:
						System.out.println("\t-> Ingrese fecha de nacimiento de la persona: ");
						sc.nextLine();
						persona.setFechaNacimiento(sc.nextLine());
						break;
					case 3:
						System.out.println("\t-> Ingrese curp de la persona: ");
						sc.nextLine();
						persona.setCurp(sc.nextLine());
						break;
					case 4:
						System.out.println("\t-> Ingrese RFC de la persona: ");
						sc.nextLine();
						persona.setRfc(sc.nextLine());
						break;
					case 5:
						System.out.println("\t-> Ingrese estatura de la persona: ");
						sc.nextLine();
						persona.setEstatura(sc.nextLine());
						break;
					case 6:
						System.out.println("\t-> Ingrese peso de la persona: ");
						sc.nextLine();
						persona.setPeso(sc.nextLine());
						break;
					case 7:
						System.out.println("\t-> Datos de la persona: "+ persona.toString());
						break;
					}
					break;
				case 5:
					System.out.println("\t-> Saliendo...");
					break;
				}
				
				if (opcion1 == 5)
				{
					break;
				}
				
			}
		}
		
	}
	
	static void Menu1()
	{
		System.out.println("------------ |Espacio Bidimensional| ------------");
		System.out.println("1) Ingresar coordenadas x e y");
		System.out.println("2) Mover");
		System.out.println("3) toString");
		System.out.println("\t-> Ingrese una opcion: ");
		
	}
	
	static void Menu2()
	{
		System.out.println("------------ |Monedero en dolares| ------------");
		System.out.println("1) Deposito");
		System.out.println("2) Retirar");
		System.out.println("3) Total");
		System.out.println("4) toString");
		System.out.println("\t-> Ingrese una opcion: ");
	}
	
	static void Menu3()
	{
		System.out.println("------------ |Fecha| ------------");
		System.out.println("1) Ingresar fecha");
		System.out.println("2) Mostrar fecha");
		System.out.println("3) toString");
		System.out.println("\t-> Ingrese una opcion: ");
	}
	
	static void Menu4()
	{
		System.out.println("------------ |Persona| ------------");
		System.out.println("1) Ingresar nombre");
		System.out.println("2) Ingresar fecha de nacimiento");
		System.out.println("3) Ingresar Curp");
		System.out.println("4) Ingresar RFC");
		System.out.println("5) Ingresar estatura");
		System.out.println("6) Ingresar peso");
		System.out.println("7) Datos de la persona");
		System.out.println("\t-> Ingrese una opcion: ");
	}
	
	static void MenuMain()
	{
		System.out.println("------------ |CLASES| ------------");
		System.out.println("1) Espacio Bidimensional");
		System.out.println("2) Monedero en dolares");
		System.out.println("3) Fecha");
		System.out.println("4) Persona");
		System.out.println("\t-> Ingrese una opción: ");
	}
	
}
